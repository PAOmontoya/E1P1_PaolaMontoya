import java.util.Scanner;

public class E1P1_PaolaMontoya {

    public static void main(String[] args) {
        Scanner leer =new Scanner(System.in);
        int menu=1;
        int otra=1;
        
        while (menu!=4){
            System.out.println("~~~~Menu~~~~");
        System.out.println("1) Número Válido");
        System.out.println("2) Reordenado de Cadenas");
        System.out.println("3) Trigonometría");
        System.out.println("4) Cerrar Menu");
        menu=leer.nextInt();
        
        if (menu<0 || menu>4){
            System.out.println("Esa opcion no es valida");
        }
        
        switch (menu){
            
            case 1://Número Valido
                while(otra==1){
                    boolean valid=true;
                System.out.println("Ingrese el numero que desea validar:");
                String num=leer.next();
                int le=num.length();
                char neg='-';
               
                for(int i=0; i<le;i++){    
                    if(i!=0 && num.charAt(i)=='-'){
                        valid=false;   
               }
                    
                    if(num.charAt(le-1)=='.'){
                        valid=false;
                    }
                    
                }//for
                
               
                if(valid==true){
                    System.out.println(num+" es Valido");
                }else{
                    System.out.println(num+" no es Valido");
                }//if result
                
                System.out.println("Desea hacerlo otra vez? S/1 N/cualquier otro numero");    
                otra=leer.nextInt();
                }//otra
                
                break;
                
            case 2://Reordenado de cadenas
                while (otra==1){
                    System.out.println("Ingrese la cadena que desea reordenar:");
                String cadena=leer.next();
                int len=cadena.length();
                
                for(int i=0; i<len; i++){
                    char n=cadena.charAt(i);
                    int nu=Character.getNumericValue(n);
                    
                    if(nu==1 || nu==2 || nu==3 || nu==4 || nu==5 || nu==6 || nu==7 || nu==8 || nu==9 ||nu==0){
                        System.out.print(nu);
                    }
                    
                } //for1
                
                for(int j=0;j<len; j++){
                    char low=cadena.charAt(j);
                    
                    if(Character.isLowerCase(low)){
                        System.out.print(low);
                    }
                }//for2
                
                for(int a=0; a<len;a++){
                    char cap=cadena.charAt(a);
                     if(Character.isUpperCase(cap)){
                        System.out.print(cap);
                    }
                }//for3
                
                
                
                
                
                System.out.println();
                
                System.out.println("Desea hacerlo otra vez? S/1 N/cualquier otro numero");    
                otra=leer.nextInt();
                }//otra
                
                break;
                
                
            case 3://Trigonometria
                
                   while(otra==1){
                       int i=0;
                   
                   double output=0, n1=0, n2=0, n3=0, numerador, deno, eq=0;
                   
                   //entrada
                   System.out.println("Ingrese el angulo(grados) que desea calcuar");
                int z=leer.nextInt();
                System.out.println("Ingrese la precision deseada:");
                int k=leer.nextInt();
   
                double rad=(z*3.14159265358979323846)/180;
                
                   //ecuacion
                   while (i<=k){
                       
                    n1=Math.pow(-1,i); 
                    n2=(2*i)+1;
                    n3=Math.pow(rad,n2);
                    
                    numerador=n1*n3;
                    deno=(2*i)+1;
                    
                    eq=numerador/deno;
                    
                   output=output+eq;
               
                    
                    
                       
                   
                       //para que se repita hasta llegar al limite
                       i++;
                   }
  
                   //salida
                   System.out.println("sin("+rad+") = "+output);
                
                   System.out.println("Desea hacerlo otra vez? S/1 N/cualquier otro numero");    
                otra=leer.nextInt();
                   
                   }//otra
                
                break;
            
            
        }//switch menu
        
        }//Cierre Menu
  
    }//static void main

   
}
